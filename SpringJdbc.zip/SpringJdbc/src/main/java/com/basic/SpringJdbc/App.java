package com.basic.SpringJdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.basic.dao.StudentDao;

/**
 * Hello world!
 *
 */
public class App 
{
    private static StudentDao bean;
	private static int insert;

	public static void main( String[] args )
    {
        System.out.println( "My Program Started" );
        
        //Spring jdbc => JdbcTemplate
        
        ApplicationContext con=
        	new ClassPathXmlApplicationContext("com/basic/Springjdbc/config.xml");
        
         StudentDao studentDao = con.getBean("studentDao",StudentDao.class);
           
         
         //for insert
         /*Student student= new Student();
         student.setId(106);
         student.setName("Babbu");
         student.setCity("Devas");
         
        int result = studentDao.insert(student);
        System.out.println("No of record inserted:"+result);*/
         
         
         
         //for update
        /* 
         Student student= new Student();
         student.setId(102);
         student.setName("Abhichek");
         student.setCity("Nimbod");
         
        int result = studentDao.change(student);
        System.out.println("No of record updated:"+result);*/
         
         //for delete
         
       
         /*int result = studentDao.delete(106);
         System.out.println("No of record deleted:"+result);*/
        
        
        
        /*JdbcTemplate template=con.getBean("jdbcTemplate",JdbcTemplate.class);
        
        // insert Query
        
        String query="insert into student (id,name,city) values(?,?,?)";
        
        //fire query
        
       int result= template.update(query,104,"Ballam","Aurowindo");
       System.out.println("No of record inserted:"+result);*/
         
         
         
         // For Single data
        
             Student    student = studentDao.getStudent(105);
             System.out.println(student);
    }
}
