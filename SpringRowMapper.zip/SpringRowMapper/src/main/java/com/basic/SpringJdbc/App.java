package com.basic.SpringJdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.basic.dao.StudentDao;

/**
 * Hello world!
 *
 */
public class App 
{
    

	private static Student student;
	private static List<Student> allStudent;

	public static void main( String[] args )
    {
        System.out.println( "My Program Started" );
        
        //Spring jdbc => JdbcTemplate
        
        ApplicationContext con=
        	new ClassPathXmlApplicationContext("com/basic/Springjdbc/config.xml");
        
         StudentDao studentDao = con.getBean("studentDao",StudentDao.class);

         //for insert
        Student student= new Student();
         student.setId(106);
         student.setName("Babbu");
         student.setCity("Devas");
         
        int result = studentDao.insert(student);
        System.out.println("No of record inserted:"+result);
     // For Single data
    /*
         Student    student = studentDao.getStudent(103);
         System.out.println(student);*/
         
         //for Multiple data
         
         List<Student> students= studentDao.getAllStudent();
         for (Student s : students) {
        	 System.out.println(s);
		}
    }
}
