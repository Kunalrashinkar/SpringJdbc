package com.basic.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.basic.SpringJdbc.Student;

public class StudentDaoImpl implements StudentDao {

	private JdbcTemplate jdbcTemplate1;
	

	public int insert(Student student) {

		// insert Query
		String query = "insert into student (id,name,city) values(?,?,?)";
		int r = this.jdbcTemplate1.update(query, student.getId(), student.getName(), student.getCity());

		return r;
	}

	public int change(Student student) {

		// updating data
		String query= "update student set name=?,city=? where id=?";
		int r = this.jdbcTemplate1.update(query,student.getName(),student.getCity(),student.getId());
		return r;
	}
	
	public int delete(int studentId) {
		
		// deleting data
		String query= "delete from student where id=?";
		int r = this.jdbcTemplate1.update(query,studentId);
		return r;
	}
	
	public Student getStudent(int studentId) {
		//Selecting Single Student Data
		
		String query="select * from student where id =?";
		
		 RowMapper< Student> rowMapper= new RowMapperImpl();
		
		Student student =this.jdbcTemplate1.queryForObject(query, rowMapper,studentId);
		return student;
	}
	
	public List<Student> getAllStudent() {
		
		// for selecting Multiple data
		String query="select * from student";
		
		List<Student> students =this.jdbcTemplate1.query(query, new RowMapperImpl());
		return students;
	}

	public JdbcTemplate getJdbcTemplate1() {
		return jdbcTemplate1;
	}

	public void setJdbcTemplate1(JdbcTemplate jdbcTemplate1) {
		this.jdbcTemplate1 = jdbcTemplate1;
	}

	

	

	

	

}
